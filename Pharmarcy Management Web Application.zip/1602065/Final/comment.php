<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="testing";

$con = new mysqli($host, $user, $password, $database);

if(isset($_POST['submit'])){
$comment=$_POST['comment'];


$sql="insert into comment(comment) values('$comment')";

$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1){
    
    header('Location: contace.html');
    exit;
}
else{
    header('Location: home1.html');
}
}

?>