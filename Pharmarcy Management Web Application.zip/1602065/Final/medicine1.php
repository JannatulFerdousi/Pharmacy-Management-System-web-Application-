<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="testing";

$con = new mysqli($host, $user, $password, $database);

if(isset($_POST['medicine'])){
$medicine=$_POST['mname'];
$brand=$_POST['bname'];
$price=$_POST['price'];
$edate=$_POST['edate'];

$sql="INSERT INTO medicine(medicine_name, brand, price,expire_date) VALUES ('$medicine','$brand','$price','$edate')";

$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1){
    $_SESSION['username']=$email;
//    $_SESSION
    header('Location: managerr.php');
    exit;
}
else{
    header('Location: managerr.php');
}
}

?>