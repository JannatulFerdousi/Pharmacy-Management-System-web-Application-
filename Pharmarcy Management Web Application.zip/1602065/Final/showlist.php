<html>
<head>
<title>
Jannat Pharmacy
</title>
<link rel="stylesheet" type="text/css" href="style6.css" >

</head>
<body style="background-color:rgba(0,0,0,0.3)">
<div class = "menu">
<div class ="leftmenu">
<h4>JANNAT PHARMACY</h4>
</div>
<div class="container" style="text-align:center;margin-top:25px;padding-left:10px"> 
<ul>
<li> <a href="home1.html">HOME </a></li>
<li><a href="about.html">ABOUT US </a> </li>
<li><a href="category.html">CATEGORY</a>
<ul>
<li><a href="cream.html">CREAM</a></li>
<li><a href="table.html">TABLET</li>
<li>CAPSULE
<ul>
<li>PAIN REMOVAL</li>

</ul>
</li>
<li>OTHER</li>
</ul>
</li>
<li ><a href="sign.html"> LOG IN </a> </li>
<li id="firstlist">CONTACT</li>
<li style="width:230px;font-weight:bold;"> MOBILE:&nbsp+01674969266</li>
</ul> 
</div>
</div><br><br>
<div class="panna" style="margin:auto;padding:20px;margin-bottom:100px;margin-top:0px,padding-right:40px;height:500px;width:700px">
<fieldset><center>
<h1 style="background-color:brown;color:white;font_size:bold">Available medicine</h1>
</center>
<center><label style="background-color:blue;color:white"></label></center>
			<table border 1 class="mytable" id = "table_id" style="width:700px;">
					<thead style="background-color:white">
				    <tr>
					
				        
				        <th width="20%"> Medicine Name</th>
				        <th width="20%">Brand Name</th>
						<th width="10%">Price</th>
						<th width="20%">Expire Date</th>
						
				    </tr>
					
				</thead>
					
				    <?php
   
    $con=mysqli_connect("localhost","root","","testing");
    if($con->connect_error){
        die("conection failed: ".$con->connect_error);
    }
    $sql="select medicine_name,brand,price,expire_date from medicine";
    $result=$con->query($sql);
    
    if($result->num_rows>0){
        
        while($row=$result->fetch_assoc()){
           echo "<tr><td>".$row["medicine_name"]."</td><td>".$row["brand"]."</td><td>".$row["price"]."</td><td>".$row["expire_date"]."</td></tr>";
                    
            
        }
        
    }

    $con->close();

    ?>
	

	</body>
	</html>