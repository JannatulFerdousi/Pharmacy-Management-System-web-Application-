<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="testing";

$con = new mysqli($host, $user, $password, $database);

if(isset($_POST['admin'])){
$user=$_POST['user'];
$pass=$_POST['pass'];

$sql="select * from admin where username='".$user."' AND password='".$pass."' limit 1";

$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1){
    $_SESSION['username']=$email;
//    $_SESSION
    header('Location: add.php');
    exit;
}
else{
    header('Location: home1.html');
}
}

?>