


<html>
<head>
<title>
Jannat Pharmacy
</title>
<link rel="stylesheet" type="text/css" href="style4.css" >

</head>
<body>
<div class = "menu">
<div class ="leftmenu">
<h4>JANNAT PHARMACY</h4>
</div>
<div class="container" style="text-align:center;margin-top:25px;padding-left:10px"> 
<ul>
<li> <a href="home1.html">HOME </a></li>
<li><a href="about.html">ABOUT US </a> </li>
<li><a href="category.html">CATEGORY</a>
<ul>
<li><a href="cream.html">CREAM</a></li>
<li><a href="table.html">TABLET</li>
<li>CAPSULE
<ul>
<li>PAIN REMOVAL</li>

</ul>
</li>
<li>OTHER</li>
</ul>
</li>
<li id="firstlist"> LOG IN</li>
<li><a href="sign.html">CONTACT</a></li>
<li style="width:230px;font-weight:bold;"> MOBILE:&nbsp+01674969266</li>
</ul> 
</div>
</div>
<div style="background-color:blue;color:white">

<div class = "background" style="background-color:#b3d9ff;height:800;width:100%">


<div style="font:bold;font-size:20;float:left">
<br><br><br>
<div>
<fieldset class="medicine"style="height:320px;width:345;padding-left:20px;padding:20px;background-color:rgba(0,0,0,0.1)">

<center><h3 style="font:bold;color:white;background-color:blue"> MEDICINE FORM</h3><br><br></center>
<form action="medicine1.php" method="post">
<label for="medicine">Medicine Name:</label>
<input type="text" placeholder=" Medicine Name" name="mname"><br><br>

<label for="brand">Brand Name:</label>
<input type="text" placeholder="Brand Name" name="bname"><br><br>

<label for="price"> Price:</label>
<input type="number" placeholder="per pcs" name="price"><br><br>

<label for="date">Expire Date:</label>
<input type="date" placeholder="Expire Date" name="edate"><br><br><br>
<center>
<h4 ><input type="Submit" value="ADD" name="medicine" style="background-color:blue;color:white;height:50px;width:50px">&nbsp&nbsp&nbsp&nbsp&nbsp <input type="reset" value="RESET"name="" style="background-color:blue;color:white;height:50px;width:50px"></h4></center>
</div>
</form>

<center>

<div style="height:500px;width:100px;padding:20px;padding-right:140px">
<fieldset>
<h5 style="font:bold;background-color:blue;color:white">SHOW ORDER</h5>
<center><h2 style="background-color:blue;color:white"></h2></center><br>
			<table border 1 class="mytable" id = "table_id" style="width:300px;">
					<thead style="background-color:white">
				    <tr>
					
				        
				        <th width="20%"> Medicine Name</th>
						<th width="20%"> Address</th>
						<th width="20%"> Amount</th>
				        
						
				    </tr>
					
				</thead>
					
				    <?php
   
    $con=mysqli_connect("localhost","root","","testing");
    if($con->connect_error){
        die("conection failed: ".$con->connect_error);
    }
    $sql="select medicine_name,address,payment from orderr";
    $result=$con->query($sql);
    
    if($result->num_rows>0){
        
        while($row=$result->fetch_assoc()){
           echo "<tr><td>".$row["medicine_name"]."</td><td>".$row["address"]."</td><td>".$row["payment"]."</td></tr>";
                    
            
        }
        
    }

    $con->close();

    ?>



    <?php
			echo	"</table>
				</fieldset>
				</div>";

?>



</form>
</center>
</div>
<br><br><br><br>

<div class="panna" style="float:right;padding:20px;margin-bottom:100px;margin-top:0px,padding-right:40px;height:500px;width:700px">
<fieldset>
<center><h3 style="background-color:blue;color:white;font:bold">MEDICINE LIST</h3></center>
<br>
			<table border 1 class="mytable" id = "table_id" style="width:700px;">
					<thead style="background-color:white">
				    <tr>
					
				        
				        <th width="20%"> Medicine Name</th>
				        <th width="20%">Brand Name</th>
						<th width="10%">Price</th>
						<th width="20%">Expire Date</th>
						
				    </tr>
					
				</thead>
					
				    <?php
   
    $con=mysqli_connect("localhost","root","","testing");
    if($con->connect_error){
        die("conection failed: ".$con->connect_error);
    }
    $sql="select medicine_name,brand,price,expire_date from medicine";
    $result=$con->query($sql);
    
    if($result->num_rows>0){
        
        while($row=$result->fetch_assoc()){
           echo "<tr><td>".$row["medicine_name"]."</td><td>".$row["brand"]."</td><td>".$row["price"]."</td><td>".$row["expire_date"]."</td></tr>";
                    
            
        }
        
    }

    $con->close();

    ?>
	<div>
<form action="managerr.php" method="post">

	<select name="mail_to" style="width:200px;height:25px;">
    <?php 
    $con=mysqli_connect("localhost","root","","testing");
               $res = mysqli_query($con,"select medicine_name  from medicine");
               while($row=mysqli_fetch_array($res))
             {
                ?>
            <option><?php echo $row["medicine_name"]; ?></option>
            <?php
            }
            ?>

</select>
<input type="submit" name ="delete" value="delete" style="height:30px;width:100px;background:blue;color:white;"></input>
</form>
    <?php
			echo	"</table>
				</fieldset>
				</div>";

?>

<?php
if(isset($_POST['delete'])){
	$name=$_POST['mail_to'];
	
	$conn=new mysqli("localhost","root","","testing");
	$ssq="delete from medicine where medicine_name='$name'";
	
	$resultt=mysqli_query($conn,$ssq);
	$conn->close();
}

?>
<form action="#" method ="post">
<select name="order" style="width:200px;height:25px;margin-top:420px;">
    <?php 
    $con=mysqli_connect("localhost","root","","testing");
               $res = mysqli_query($con,"select medicine_name  from orderr");
               while($row=mysqli_fetch_array($res))
             {
                ?>
            <option><?php echo $row["medicine_name"]; ?></option>
            <?php
            }
            ?>

</select>
<input type="submit" name ="deleted" value="delete" style="height:30px;width:100px;background:blue;color:white;margin-top:5px;"></input>
</form>



<?php
if(isset($_POST['deleted'])){
	$name=$_POST['order'];
	
	$conn=new mysqli("localhost","root","","testing");
	$ssq="delete from orderr where medicine_name='$name'";
	
	$resultt=mysqli_query($conn,$ssq);
	$conn->close();
}

?>

    <?php
			echo	"</table>
				</fieldset>
				</div>";

?>

<div class = "background" style="background-color:#b3d9ff;height:20px;width:100%;padding:left" >
<footer  style="margin-top:0px;padding-left:0px;">
<h6 style="margin-left:500px"> <a href="home1.html">  Home page</a></h6>

</footer>
</div>
</div>
</div>




</body>
</html>