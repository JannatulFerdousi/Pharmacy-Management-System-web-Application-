<?php
	$servername ="localhost";
	$username ="root";
	$password ="";
	$databasename ="testing";
	$con = new mysqli($servername, $username, $password, $databasename);

if (isset($_POST['btn']))
{
	echo "Registration complete";

	
	$fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$mob = $_POST['mob'];
	$email = $_POST['email'];
	$uname = $_POST['uname'];
	$pass = $_POST['pass'];
	

	$sql = mysqli_query($con, "insert into signup(first_name, last_name, mobile, email, username, password) values ('$fname', '$lname', '$mob', '$email', '$uname', '$pass')");
}
else
{
	echo "Registration error";	
}

?>





