<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="testing";

$con = new mysqli($host, $user, $password, $database);

if(isset($_POST['order'])){
$name=$_POST['name'];
$address=$_POST['address'];
$payment=$_POST['payment'];


$sql="insert into orderr(medicine_name,address,payment) values('$name','$address','$payment')";

$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)==1){
    $_SESSION['username']=$email;
//    $_SESSION
    header('Location: contace.html');
    exit;
}
else{
    header('Location: home1.html');
}
}

?>