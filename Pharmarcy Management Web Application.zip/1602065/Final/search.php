<?php
session_start();
$host="localhost";
$user="root";
$password="";
$database="testing";

$con = new mysqli($host, $user, $password, $database);

if(isset($_POST['Submit'])){
 header('Location: showlist.php');
}

?>